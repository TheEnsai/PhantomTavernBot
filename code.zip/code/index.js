
const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
let questData = JSON.parse(fs.readFileSync('./data/quests.json', 'utf8'));
const cooldowns = new Map();
const dailyCooldowns = new Map();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers // THIS IS MANDATORY
  ]
});
let activeBattles = {};
client.setMaxListeners(20); // Increase the limit from 10 to 20

function getColor(number) {
    if (number === 0) return 'Green';
    // Standard European Roulette color pattern
    if ((number >= 1 && number <= 10) || (number >= 19 && number <= 28)) {
        return (number % 2 === 0) ? 'Black' : 'Red';
    } else {
        return (number % 2 === 0) ? 'Red' : 'Black';
    }
}

let players = require('./data/players.json');
const items = require('./data/items.json');
const minions = require('./data/minion.json');
const boss = require('./data/boss.json');
const quests = require('./data/quests.json');
const achievementData = require('./data/achievements.json');
const { MessageEmbed } = require('discord.js'); // Assuming you use Embeds

function calculateStats(userId) {
    const player = players[userId];
    if (!player) return;

    // 1. Reset base stats
    player.stats = { ...player.baseStats };

    // 2. Use the correct property name: equippedSlots
    const slots = player.equippedSlots || {}; 

    // 3. Get all item names from the slots object
    const itemNames = Object.values(slots);

    itemNames.forEach(itemName => {
        // Only process if it's not null/undefined
        if (itemName) {
            const item = items[itemName];
            if (item && item.stats) {
                for (let stat in item.stats) {
                    player.stats[stat] = (player.stats[stat] || 0) + item.stats[stat];
                }
            }
        }
    });
}

/**
 * Checks if the user who sent the message has a specific role by name.
 * Returns true if they have it, false otherwise.
 */
function hasRole(message, roleName) {
    // 1. Check if the message was sent in a server (Guild)
    if (!message.guild) return false;
    
    // 2. Check if the member object exists
    if (!message.member) return false;
    
    // 3. Search the member's roles cache for the specific name
    return message.member.roles.cache.some(role => role.name === roleName);
}

function getCombatResults(p, minion, isPlayerTurn) {
    const s = p.stats;
    let results = { damage: 0, heal: 0, reflected: 0, dodged: false };

    if (isPlayerTurn) {
        // --- PLAYER ATTACKING ---
        let isCrit = (Math.random() * 100) < s.critChance;
        let baseDmg = s.dmg;
        
        if (isCrit) {
            // Base 1.5 + (critDamage points * 0.01)
            let critMult = 1.5 + (s.critDamage * 0.01);
            baseDmg *= critMult;
        }

        // Apply enemy armor/MR logic here...
        results.damage = Math.floor(baseDmg);
        
        // Lifesteal calculation
        results.damage = Math.floor(baseDmg);

// Lifesteal: 1 point = 1% of damage dealt
// Example: If you have 15 points, you heal for 15% of the damage dealt.
results.heal = Math.floor(results.damage * (s.lifesteal / 100));
    } else {
        // --- MINION ATTACKING ---
        // Dodge check
        if ((Math.random() * 100) < (s.dodgeChance * 0.5)) {
            results.dodged = true;
        } else {
            // Damage calculation with Crit Reduction
            let incoming = minion.dmg;
            // ... (apply your armor logic) ...
            
            results.damage = incoming;
            results.reflected = s.thorns; // Thorns dmg back to minion
        }
    }
    return results;
}

function calculateDamage(baseDmg, targetDef) {
    // 1 point of Defense/MagicRes = 0.5 reduction
    let reduction = (targetDef || 0) * 0.2;
    
    // Calculate final damage
    // Math.max(1, ...) ensures that if reduction is higher than baseDmg, 
    // the result is 1 instead of 0 or a negative number.
    let finalDmg = Math.max(5, baseDmg - reduction);
    
    return Math.floor(finalDmg);
}

async function checkCompletionistAchievement(userId, channel) {
    const p = players[userId];
    
    // 1. Get all public (non-secret) achievements
    // We assume 'achievementData' is the array loaded from achievements.json
    const publicAchievements = achievementData.filter(a => !a.secret);
    
    // 2. Check if every public achievement is in the player's completed array
    const allPublicCompleted = publicAchievements.every(a => 
        p.achievements.completed.includes(a.id)
    );

    // 3. If they finished all, trigger BA001
    const ba001 = achievementData.find(a => a.id === 'BA001');
    if (allPublicCompleted && ba001 && !p.achievements.completed.includes(ba001.id)) {
        
        // Directly grant BA001
        p.achievements.completed.push(ba001.id);
        
        // Grant the soul of phantoms if it's in the JSON
        if (ba001.itemReward) {
            if (!p.inventory) p.inventory = [];
            p.inventory.push(ba001.itemReward);
            channel.send(`✨ **Rare Item Found:** You received **${ba001.itemReward}**!`);
        }
        
        channel.send(`🎉 **SECRET ACHIEVEMENT UNLOCKED:** You have completed every challenge! **${ba001.name}** has been earned!`);
        savePlayers();
    }
}

async function updateAchievementProgress(userId, achKey, amount, channel) {
   if (!players[userId]) {
        players[userId] = { ignis: 0, inventory: [], dungeon: { active: false} };
    }

    if (!players[userId].achievements) {
        players[userId].achievements = { completed: [], progress: {} };
    }
    const p = players[userId];
    const ach = achievementData.find(a => a.key === achKey);
    
    if (!ach) return;
    
    // Now it is safe to access p.achievements.completed
    if (p.achievements.completed.includes(ach.id)) return;

    // 2. Update Progress
    p.achievements.progress[achKey] = (p.achievements.progress[achKey] || 0) + amount;
    console.log(`[DEBUG] Progress for ${achKey} is now ${p.achievements.progress[achKey]}`);

    // 3. Check for Completion
    if (p.achievements.progress[achKey] >= ach.target) {
        console.log(`[DEBUG] Target reached! Achievement ${ach.id} completed!!!.`);
        p.achievements.completed.push(ach.id);
        
        // Handle Rewards
        const rewardItem = ach.itemReward || ach.Itemreward; 
        if (rewardItem) {
            if (!p.inventory) p.inventory = [];
            p.inventory.push(rewardItem);
            if (channel) channel.send(`✨ **Exclusive Item Found:** You received **${rewardItem}**!`);
        }
        const ignisReward = ach.reward;
        if(ignisReward >= 1)
        {
            p.ignis = p.ignis + ignisReward;
            if (channel) channel.send(`🏆 **Achievement Unlocked:** ${ach.name}! Earned ${ignisReward} ignis!`);
        }
        else
        if (channel) channel.send(`🏆 **Achievement Unlocked:** ${ach.name}!`);
        
        // 4. TRIGGER: BA001 Logic Placeholder
        // Call your new BA001 function here when you finish designing it!
    }

    // 5. Always save the state
    savePlayers();
}


// Add this helper to calculate the reward
function rollDungeonChest(p) {
    const roll = Math.random() * 100;
    let type = 'Silver';
    let reward = 500; // Base amount

    if (roll > 95) { type = 'Obsidian'; reward = 5000; }
    else if (roll > 70) { type = 'Gold'; reward = 2000; }

    p.ignis += reward;
     // Add the loot
    return `🎁 **DUNGEON CLEARED!** You found a **${type} Chest** containing **${reward} Ignis!**`;
}

function triggerDungeonRoom(message, p) {
    const rooms = ['Tavern', 'Lava', 'Tipping', 'Rare'];
    const selectedRoom = rooms[Math.floor(Math.random() * rooms.length)];
    p.dungeon.inRoom = true;
    p.dungeon.currentRoomType = selectedRoom;

    let msg = `🌀 **You found a special room: ${selectedRoom}!**\n`;
    
    if (selectedRoom === 'Tavern') {
        msg += "You can `!escape` now to bank your current Ignis, or `!continue`.";
    } else if (selectedRoom === 'Lava') {
        let heal = Math.floor((p.stats.maxHealth - p.battle.pHp) * 0.20); // Heals 20% of missing HP
        p.battle.pHp += heal;
        msg += `The fountain restores ${heal} HP. Type \`!nextwave\` to continue.`;
        p.dungeon.inRoom = false; // Auto-resolve
    } else if (selectedRoom === 'Tipping') {
        msg += "A soulless creature looks hungry. Use `!tip <amount>` to bless him.";
    } else if (selectedRoom === 'Rare') {
        msg += "A hidden vault! It contains a chest. Use `!openchest`.";
    }
    
    message.channel.send(msg);
}

function getPlayerData(userId) {
    const data = JSON.parse(fs.readFileSync('./data/players.json', 'utf8'));
    // If the user doesn't exist in the JSON, return a default object
    return data[userId] || { 
        id: userId, 
        balance: 0, 
        stats: {}, 
        completedQuests: [], 
        completedAchievements: [] 
    };
}   

function savePlayerData(userId, userData) {
    const data = JSON.parse(fs.readFileSync('./data/players.json', 'utf8'));
    data[userId] = userData;
    fs.writeFileSync('./data/players.json', JSON.stringify(data, null, 2));
}

function getPlayerBattleStats(p) {
    // Start with base stats
    let totalDmg = p.stats.dmg || 0;
    let totalArmor = p.stats.armor || 0;
    let totalMagicRes = p.stats.magicRes || 0;
    let totalHp = p.stats.maxHealth || 100;

    // Add bonuses from equipped items
    for (let slot in p.equipped) {
        let item = p.equipped[slot];
        if (item) {
            totalDmg += (item.dmg || 0);
            totalArmor += (item.armor || 0);
            totalMagicRes += (item.magicRes || 0);
            totalHp += (item.hp || 0);
        }
    }

    return { totalDmg, totalArmor, totalMagicRes, totalHp };
}

function getPlayerTotalStats(player) {
    // Start with a copy of base stats so we don't mess up the original
    let totalStats = { ...player.baseStats };

    if (player.equipped) {
        player.equipped.forEach(itemName => {
            const item = items[itemName];
            if (item && item.stats) {
                for (let stat in item.stats) {
                    // Add item stat to our total
                    totalStats[stat] = (totalStats[stat] || 0) + item.stats[stat];
                }
            }
        });
    }
    return totalStats;
}

function ensurePlayerExists(userId) {
    if (!players[userId]) {
        players[userId] = {
            ignis: 0,
            inventory: [],
            gachaPot: { "Almost Forged": 0, "Obsidian": 0 }
        };
    } else if (!players[userId].gachaPot) {
        // This adds the field to old players who don't have it yet
        players[userId].gachaPot = { "Almost Forged": 0, "Obsidian": 0 };
    }
}

function calculateFinalStats(userId) {
    const p = players[userId];
    const items = require('./data/items.json');
    
    // Reset to base
    p.stats = { ...p.baseStats };

    // Add bonuses
    for (let slot in p.equippedSlots) {
        const itemName = p.equippedSlots[slot];
        if (itemName && items[itemName]) {
            const bonuses = items[itemName].stats;
            for (let stat in bonuses) {
                if (p.stats.hasOwnProperty(stat)) {
                    p.stats[stat] += bonuses[stat];
                }
            }
        }
    }
}

function savePlayers() {
  fs.writeFileSync('./data/players.json', JSON.stringify(players, null, 2));
}

client.once('ready', () => {
  console.log('Bot is online!');
});

/**
 * Updates progress and checks for completion.
 * @param {string} userId - ID of the player
 * @param {string} questKey - The key defined in quests.json
 * @param {number} amount - How much progress to add
 */
async function checkCompletionistAchievement(userId, channel) {
    const p = players[userId];
    
    // 1. Get all public (non-secret) achievements
    // We assume 'achievementData' is the array loaded from achievements.json
    const publicAchievements = achievementData.filter(a => !a.secret);
    
    // 2. Check if every public achievement is in the player's completed array
    const allPublicCompleted = publicAchievements.every(a => 
        p.achievements.completed.includes(a.id)
    );

    // 3. If they finished all, trigger BA001
    const ba001 = achievementData.find(a => a.id === 'BA001');
    if (allPublicCompleted && ba001 && !p.achievements.completed.includes(ba001.id)) {
        
        // Directly grant BA001
        p.achievements.completed.push(ba001.id);
        
        // Grant the soul of phantoms if it's in the JSON
        if (ba001.itemReward) {
            if (!p.inventory) p.inventory = [];
            p.inventory.push(ba001.itemReward);
            channel.send(`✨ **Rare Item Found:** You received **${ba001.itemReward}**!`);
        }
        
        channel.send(`🎉 **LEGENDARY ACHIEVEMENT UNLOCKED:** You have completed every challenge! **${ba001.name}** has been earned!`);
        savePlayers();
    }
}

function updateQuestProgress(userId, questKey, amount = 1, channel = null) { // Add '= null' here
    if (!players[userId]) {
        players[userId] = {
            ignis: 0,
            lastDaily: 0,
            lastForge: 0,
            inventory: [],
            dungeon: { active: false},
            achievements: { completed: [], progress: {} }
        };
    }
    console.log(`DEBUG: Updating ${userId} for quest ${questKey} with amount ${amount}`);
    const p = players[userId];
    if (!p) return;

    if (!p.quests) p.quests = { progress: {}, completed: [] };
    if (!p.quests.progress) p.quests.progress = {};

    p.quests.progress[questKey] = (p.quests.progress[questKey] || 0) + amount;

   questData.forEach(q => {
        if (p.quests.progress[q.key] >= q.target && !p.quests.completed.includes(q.id)) {
            // 1. Mark as completed and add reward
            p.quests.completed.push(q.id);
            p.ignis = (p.ignis || 0) + q.reward;

            // 2. Update the Ignis quest tracker (if this isn't the quest itself)
            if (q.key !== 'total_ignis_earned') {
                updateQuestProgress(userId, 'total_ignis_earned', q.reward, channel);
            }

            // 3. Trigger Achievement Check (for Completionist)
            // We pass the length of the completed array as the 'amount'
            const totalFinished = p.quests.completed.length;
            updateAchievementProgress(userId, 'quests_completed', 1, channel);

            // 4. Send the notification
            if (channel) {
                channel.send(`🎉 **Quest Complete!** <@${userId}> finished **${q.name}** and earned **${q.reward} Ignis**!`);
            }
        }
    });}
const { EmbedBuilder } = require('discord.js');

client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
    
    // Fetch all members in all guilds the bot is in
    const guilds = client.guilds.cache;
    for (const [id, guild] of guilds) {
        await guild.members.fetch();
        console.log(`Cached members for guild: ${guild.name}`);
    }
});


client.on('guildMemberUpdate', (oldMember, newMember) => {
    // 1. Define the roles to watch
    console.log("Role update event fired!"); // This MUST show up if it's working
    const roleQuests = {
        '1483485195779969045': 'rank_tavernist',
        '1483485409232294031': 'rank_tavernist_ii',
        '1483485548520931519': 'rank_tavernist_iii',
        '1483485642922000424': 'rank_phantom',
        '1483485823180607540': 'rank_phantom_ii',
        '1483485944085614775': 'rank_phantom_iii',
        '1483486072393437194': 'rank_collector',
        '1483486189418971146': 'rank_exiled'
    };

    // 2. Determine which roles were just added
    const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));

    // 3. Trigger the quest for each added role found in our list
    addedRoles.forEach(role => {
    if (roleQuests[role.id]) {
        // 1. Update the quest (passing null for channel is fine)
        updateQuestProgress(newMember.id, roleQuests[role.id], 1, null);
        
        // 2. Fetch the channel by its ID (Replace 'YOUR_CHANNEL_ID' with a real one)
        const channel = newMember.guild.channels.cache.get('1486483001230491880');
        
        // 3. Send the message if the channel exists
        if (channel) {
            channel.send(`🎉 Congratulations <@${newMember.id}>! You've earned the **${role.name}** rank!`);
        }
        
        console.log(`Quest fulfilled for user ${newMember.id} via role: ${role.name}`);
    }
});
});
let isStage = false;

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

// THIS is what you add to listen for role changes


    // A single helper function to handle all inventory display
    const showInventory = (msg, pageIndex) => {
        const userId = msg.author.id;
        const p = players[userId];

        if (!p || !p.inventory || p.inventory.length === 0) {
            return msg.reply("Your inventory is empty!");
        }

        const itemsPerPage = 5;
        const totalPages = Math.ceil(p.inventory.length / itemsPerPage);
        
        // Ensure page is within bounds
        const currentPage = Math.max(0, Math.min(pageIndex, totalPages - 1));
        p.currentPage = currentPage; 

        const start = currentPage * itemsPerPage;
        const pageItems = p.inventory.slice(start, start + itemsPerPage);

        let output = `--- ${msg.author.username}'s Inventory (Page ${currentPage + 1}/${totalPages}) ---\n\`\`\`ansi\n`;

        pageItems.forEach((itemName, index) => {
            const item = items[itemName] || {};
            const rarity = item.rarity || "Common";
            
            // --- NEW LOGIC: Type and Style ---
            const itemType = item.type ? `[${item.type}]` : "";
            const itemStyle = (item.type === "Weapon" && item.style) ? `(${item.style}) ` : "";

            // ANSI Color Mapping
            let colorCode = "34"; // Default Blue
            if (rarity === "Legendary") colorCode = "1;33";      // Yellow
            else if (rarity === "Epic") colorCode = "35";      // Purple
            else if (rarity === "Rare") colorCode = "33";      // Orange/Yellow
            else if (rarity === "Exclusive") colorCode = "1;31"; // Red

            // Stats string
            let statsText = "";
            if (item.stats) {
                const activeStats = Object.entries(item.stats)
                    .filter(([k, v]) => v !== 0 && v !== undefined && v !== null)
                    .map(([k, v]) => k.includes("Increase") ? `${k}: ${v}%` : `${k}: ${v}`);
                statsText = activeStats.length > 0 ? ` | ${activeStats.join(', ')}` : "";
            }

            // Output line construction
            output += `\u001b[0;${colorCode}m${start + index + 1}. ${itemType} ${itemStyle}${itemName} (${rarity}${statsText})\u001b[0m\n`;
        });

        output += "```\nType \"!page <number>\" to switch pages.";
        return msg.channel.send(output);
    };

    // Combined command handling
    if (message.content.startsWith('!inventory')) {
        const p = players[message.author.id];
        return showInventory(message, p ? p.currentPage || 0 : 0);
    }

    if (message.content.startsWith('!page ')) {
        const args = message.content.split(' ');
        const requestedPage = parseInt(args[1]) - 1;
        if (isNaN(requestedPage)) return message.reply("Please enter a valid page number.");
        return showInventory(message, requestedPage);
    }



  if (message.author.bot) return;

  const userId = message.author.id;

 if (!players[userId]) {
    players[userId] = {
  ignis: 0,
  hammer:false,
  inventory: [],
  equippedSlots: {
    weapon: null,
    helmet: null,
    bodyarmor: null,
    leggings: null,
    boots: null,
    ring: null
  },
  baseStats: {
    maxHealth: 100,
    dmg: 10,
    speed: 10,
    armor: 0,
    magicRes: 0,
    lifesteal: 0,
    luck: 0,
    income: 0,
    dodgeChance: 0,
    critChance: 0,
    critDamage: 0,
    critReduction: 0,
    critDmgReduction: 0,
    damageReduction: 0,
    thorns: 0
  },
  stats: {
    maxHealth: 100,
    dmg: 10,
    speed: 10,
    armor: 0,
    magicRes: 0,
    lifesteal: 0,
    luck: 0,
    income: 0,
    dodgeChance: 0,
    critChance: 0,
    critDamage: 0,
    critReduction: 0,
    critDmgReduction: 0,
    damageReduction: 0,
    thorns: 0,
    maxHealthIncrease: 0
  },
  gachaPot: {
    "Almost Forged": 0,
    Obsidian: 0
  },
  currentPage: 0,
  battle: {
    active: false,
    minion: null,
    mHp: 0,
    mArmor: 0,
    mMagicRes: 0,
    pHp: 0,
    pArmor: 0,
    pMagicRes: 0
  },
  dungeon: {
    active: false,
    difficulty: null,
    currentWave: 0,
    totalWaves: 0,
    isBossDungeon: false,
    inRoom: false,
    roomType: null,
    blessed: false,
    roomVisited: false,
    roomJustFinished: false,
    HasHammer: false
  }
}
    savePlayers(); 
}

// !stages: View and select a stage
if (message.content.startsWith('!stages')) {

    const p = players[message.author.id];
    const args = message.content.split(' ');
    // Ensure currentStage exists for the player
    if (!p.currentStage) p.currentStage = 1;
    let currentMax = parseInt(p.currentStage);
    
    // Selection logic
    if (args.length > 1) {
        const selected = parseInt(args[1]);
        if (isNaN(selected) || selected < 1 || selected > 5) return message.reply("Pick a stage between 1-5.");
        if (selected > currentMax) return message.reply(`🔒 Stage ${selected} is locked! Clear Stage ${currentMax} first.`);
        isStage = true
        p.selectedStage = selected;
        savePlayers();
        
        return message.reply(`✅ Stage ${selected} selected! Type \`!dungeon\` to enter.`);
    }
    
    // Display logic
    let output = "🗺️ **Dungeon Stages:**\n";
    for (let i = 1; i <= 5; i++) {
        let status = (i < currentMax) ? "✅ Cleared" : (i === currentMax ? "⚔️ Available" : "🔒 Locked");
        output += `**Stage ${i}**: ${status}\n`;
    }
    return message.reply(output + "\n*Type `!stages <number>` to select, then `!dungeon`.*");
}

// !dungeon: Starts the chosen stage
if (message.content.startsWith('!dungeon')) {
    const p = players[message.author.id];
    if (p.dungeon?.active) return message.reply("You are already in a dungeon!");
    // Check if the user typed !dungeon easy, medium, or hard
    const args = message.content.split(' ');
    const inputDifficulty = args[1] ? args[1].toLowerCase() : null;
    
    // Default to 'medium' if no valid difficulty is provided
    const validDifficulties = ['easy', 'medium', 'hard'];
    const difficulty = validDifficulties.includes(inputDifficulty) ? inputDifficulty : (p.difficulty || 'medium');

    // Save the difficulty to the player object so it remembers it for next time
    p.dungeon.difficulty = difficulty;

    const stage = p.selectedStage || p.currentStage || 1;
    
    // Wave logic based on difficulty
    let btype = '!dungeon';
    let waves = 5;
    
    if (difficulty === 'easy') waves = 3;
    if(isStage === true){
        waves = 5;
        btype = '!stages';
        if (stage === 5) waves = 7;
        if(stage === 4) waves = 7;
        if(stage === 3) waves = 6;
    }
    

    p.dungeon = {
        type: btype,
        active: true,
        stage: stage,
        difficulty: difficulty, // Save difficulty in dungeon object
        currentWave: 0,
        totalWaves: waves,
        // ... (rest of your object)
    };
 
    savePlayers();console.log(p.dungeon.type)
    if(isStage){
           return message.reply(`🏰 **Stage ${stage} started !** ${waves} waves ahead. Type \`!nextwave\` to begin.`);
    }
    else{
           return message.reply(`🏰 **Dungeon(${p.dungeon.difficulty.toUpperCase()}) has started!** ${waves} waves ahead. Type \`!nextwave\` to begin.`);
}

    }
 
if (message.content.startsWith('!nextwave')) {
    const userId = message.author.id;
    const p = players[userId];
    if (!p.dungeon?.active) return message.reply("You aren't in a dungeon!");
    if (p.battle?.active) return message.reply("Finish your current fight first!");

    const s = p.stats || {};

    // 1. Room Logic
    if (p.dungeon.roomJustFinished) {
        p.dungeon.roomJustFinished = false; 
    } 
    else if (p.dungeon.currentWave > 0 && p.dungeon.currentWave % 2 === 0 && !p.dungeon.roomVisited) {
        const rooms = ['Tavern', 'Lava', 'Tipping', 'Rare'];
        p.dungeon.roomType = rooms[Math.floor(Math.random() * rooms.length)];
        p.dungeon.inRoom = true;
        p.dungeon.roomVisited = true;
        savePlayers();
        return message.channel.send(`🌀 **You found a ${p.dungeon.roomType} room!**\n
            Use !drink in Lava Room to restore some hp \n, !escape in Tavern Room to leave dungeon early and gain bonus ignis \n, 
            !tip<100-1000> in Tipping Room to give ignis to some poor soulless creature, in return he will weaken your next non-boss enemy\n,
            !openchest! in Rare Room to open a random chest \n
            If you aren't interested use **!nextwave** to continue!`);
    }

    p.dungeon.currentWave++;
    p.dungeon.roomVisited = false;  

    // 2. Dungeon Completion & Chest Rewards
    if (p.dungeon.currentWave > p.dungeon.totalWaves) {
        // Boss Kill Achievement Check
        if (p.battle.minion && p.battle.minion.isBoss) {
            updateAchievementProgress(userId, 'boss_kills', 1, message.channel);
        }

        // --- RESTORED STAGE & DIFFICULTY ACHIEVEMENTS ---
        const diff = p.dungeon.difficulty;
        const stageNum = parseInt(p.dungeon.stage);
         if (p.dungeon.type === '!dungeon' && diff === 'easy') {
            updateQuestProgress(userId, 'dungeon_easy_wins', 1, message.channel);
        }
         if (p.dungeon.type === '!dungeon' && diff === 'medium') {
            updateQuestProgress(userId, 'dungeon_medium_wins', 1, message.channel);
        }
        if (p.dungeon.type === '!dungeon' && diff === 'hard') {
            updateAchievementProgress(userId, 'dungeon_hard_wins', 1, message.channel);
        }

        if (p.dungeon.type === '!stages') {
            if (stageNum === 4) updateAchievementProgress(userId, 'stage_4_complete', 1, message.channel);
            if (stageNum === 5) updateAchievementProgress(userId, 'stage_5_complete', 1, message.channel);
        }

        if (p.battle.minion?.name === "Soulless Creature") {
            updateAchievementProgress(userId, 'b2_completed', 1, message.channel);
        }

        // Progression Logic
        let currentStage = parseInt(p.currentStage) || 1;
        if(p.dungeon.type === '!stages') {
            if (stageNum === currentStage && currentStage < 5) {
                p.currentStage = currentStage + 1;
                if (stageNum === 1) updateQuestProgress(userId, 'stage_1_complete', 1, message.channel);
                message.channel.send(`✨ **Stage ${stageNum} Cleared! Stage ${p.currentStage} is now unlocked!**`);
            }
        }
        
        // --- CHEST REWARD SYSTEM (With Luck Scaling) ---
        // Luck: 0.5% per point reduces the roll (making it easier to hit low numbers)
        const luckBonus = (s.luck || 0) * 0.005;
        const roll = Math.max(0, Math.random() - luckBonus);
        
        let chestType = "Silver";
        if (diff === 'hard') {
            if (roll < 0.15) chestType = "Obsidian";
            else if (roll < 0.50) chestType = "Gold";
        } else if (diff === 'medium') {
            if (roll < 0.05) chestType = "Obsidian";
            else if (roll < 0.25) chestType = "Gold";
        } else {
            if (roll < 0.01) chestType = "Obsidian";
            else if (roll < 0.10) chestType = "Gold";
        }

        let goldWon = 0;
        if (chestType === "Silver") goldWon = Math.floor(Math.random() * 901) + 300;
        else if (chestType === "Gold") goldWon = Math.floor(Math.random() * 1501) + 1000;
        else if (chestType === "Obsidian") goldWon = Math.floor(Math.random() * 2001) + 3000;
        
        p.ignis = (p.ignis || 0) + goldWon;
        updateQuestProgress(userId, 'total_ignis_earned', goldWon, message.channel);
        isStage = false;
        // --- CUSTOM VICTORY MESSAGE FOR APPRENTICE ---
        if (p.battle.minion?.name === "Rebane - Collector's apprentice") {
            p.dungeon.active = false;
            p.dungeon.currentWave = 0;
            savePlayers();
            return message.channel.send(`🌑 **THE SHADOW DISSIPATES...**\nAs the **Collector's Apprentice** falls, he leaves behind a faint trail of ink and a **${chestType} Chest**. \n*"Master... I have failed..."*\n\n🏆 You found **${goldWon} Ignis** inside!`);
        }

        // --- STAGE 5 / HAMMER LOGIC ---
        if (p.dungeon.type === '!stages' && stageNum === 5) {
            p.dungeon.active = false;
            p.dungeon.currentWave = 0;
            p.hammer = true;
            savePlayers();
            return message.reply(`🏆 **DUNGEON CLEARED!**\nYou opened a **${chestType} Chest** and found **${goldWon} Ignis**! You also found a hammer, what could you do with that??`);
        }

        // Standard Reset Logic
        p.dungeon.active = false;
        p.dungeon.currentWave = 0;
        p.dungeon.stage = 1;
        savePlayers(); 
        return message.reply(`🏆 **DUNGEON CLEARED!**\nYou opened a **${chestType} Chest** and found **${goldWon} Ignis**!`);
    }

    // 3. Enemy Spawn Logic
    let enemy;
    if (p.dungeon.type === '!ruins_secret') {
        enemy = boss['collectors_apprentice'];
        message.channel.send(`🌑 **THE SHADOW REVEALS ITSELF.**\n**${enemy.name}**: *" ${enemy.dialogue} "*`);
    } 
    else if (p.dungeon.secretBossTrigger) {
        enemy = boss['soulless_creature'];
        p.dungeon.secretBossTrigger = false;
        message.channel.send(`🌑 **A chill fills the air...**\n**${enemy.name}**: *" ${enemy.dialogue} "*`);
    } 
    else if (p.dungeon.type === '!stages' && p.dungeon.stage === 5 && p.dungeon.currentWave === p.dungeon.totalWaves) {
        enemy = boss['kragnars_fire_puppet'];
        message.channel.send(`🔥 **THE FINAL CHALLENGE!** 🔥\n**${enemy.name}**: *" ${enemy.dialogue} "*`);
    } 
    else if (p.dungeon.difficulty === 'hard' && p.dungeon.currentWave === p.dungeon.totalWaves) {
        const bossList = Object.values(boss);
        const dungeonBosses = bossList.filter(b => b.fight === 'dungeon');
        enemy = dungeonBosses[Math.floor(Math.random() * dungeonBosses.length)];
        message.channel.send(`🔥 **THE FINAL CHALLENGE!** 🔥\n**${enemy.name}**: *" ${enemy.dialogue} "*`);
    } 
    else {
        enemy = minions[Math.floor(Math.random() * minions.length)];
        message.channel.send(`⚔️ **Wave ${p.dungeon.currentWave}/${p.dungeon.totalWaves}**: A **${enemy.name}** appears!`);
    }

    // 4. HP Persistence
    const maxHp = (s.maxHealth || 100) * (1 + ((s.maxHealthIncrease || 0) * 0.01));
    p.battle = { 
        active: true, minion: enemy, mHp: enemy.hp || 100, 
        pHp: (p.dungeon.currentWave === 1) ? maxHp : (p.battle?.pHp || maxHp),
        pArmor: s.armor || 0, pMagicRes: s.magicRes || 0 
    };
    savePlayers();
}



// !tip for the Tipping Room
if (message.content.startsWith('!tip')) {
    const p = players[message.author.id];
    const args = message.content.split(' ');
    const amount = parseInt(args[1]);
    
    if (!p.dungeon?.inRoom || p.dungeon.roomType !== 'Tipping') 
        return message.reply("You aren't in a Tipping room!");

    // --- SECRET BOSS TRIGGER ---
    if (amount === 1) {
        p.dungeon.inRoom = false;
        p.dungeon.roomJustFinished = true;
        p.dungeon.secretBossTrigger = true;
        savePlayers();
        return message.reply("🌑 ...You tipped 1 and tried to leave, however the creature starts moving. Type **!nextwave** to face your fate.");
    }

    // --- BA005 ACHIEVEMENT TRIGGER (The Millionaire) ---
    if (amount >= 1000000) {
        if (p.ignis < amount) return message.reply("You don't have enough Ignis!");
        
        p.ignis -= amount;
        updateAchievementProgress(message.author.id, 'b5_completed', 1, message.channel);
        
        // Treat this as a "Blessed" status too
        p.dungeon.blessed = true;
        p.dungeon.inRoom = false; 
        p.dungeon.roomJustFinished = true;
        
        savePlayers();
        return message.reply("💰 **THE MILLIONAIRE!** You have gained the ultimate blessing. Type **!nextwave**.");
    }

    // --- NORMAL TIP LOGIC ---
    if (isNaN(amount) || amount < 100 || amount > 1000) 
        return message.reply("Tip between **100 and 1000** Ignis!");
    
    if (p.ignis < amount) 
        return message.reply("You don't have enough Ignis!");
    
    p.ignis -= amount;
    p.dungeon.blessed = true;
    p.dungeon.inRoom = false; 
    p.dungeon.roomJustFinished = true;
    
    savePlayers();
    return message.reply("✨ The creature is blessed! Type **!nextwave** to start the battle.");
}
 
// !openchest for Rare Room
if (message.content.startsWith('!openchest')) {
    const p = players[message.author.id];
    if (!p.dungeon?.active || p.dungeon.roomType !== 'Rare') {
        return message.reply("There is no chest to open!");
    }

    const roll = Math.random();
    const diff = p.dungeon.difficulty;
    let chestType = "Silver";

    if (diff === 'hard') {
        if (roll < 0.15) chestType = "Obsidian";
        else if (roll < 0.50) chestType = "Gold";
    } else if (diff === 'medium') {
        if (roll < 0.05) chestType = "Obsidian";
        else if (roll < 0.25) chestType = "Gold";
    } else { 
        if (roll < 0.01) chestType = "Obsidian";
        else if (roll < 0.10) chestType = "Gold";
    }

    let goldWon = 0;
        if (chestType === "Silver") goldWon = Math.floor(Math.random() * 901) + 150;
        else if (chestType === "Gold") goldWon = Math.floor(Math.random() * 1501) + 600;
        else if (chestType === "Obsidian") goldWon = Math.floor(Math.random() * 2001) + 1500;

    p.gold = (p.gold || 0) + goldWon;
    p.dungeon.inRoom = false;
    p.dungeon.roomJustFinished = true;
    
    savePlayers();
    return message.reply(`🎁 You found a hidden **${chestType} Chest** in the room! Inside was **${goldWon} Gold**!`);
}

if (message.content.startsWith('!drink')) {
    const p = players[message.author.id];
    
    // Check if the player is actually in a dungeon and if the room is a Lava room
    // Assuming you store the room type in p.dungeon.roomType
    if (!p.dungeon?.active || p.dungeon.roomType !== 'Lava') {
        return message.reply("You can only drink from the Lava fountain when you are in a Lava Room!");
    }

    const s = p.stats || { maxHealth: 100, maxHealthIncrease: 0 };
    const healthIncrease = s.maxHealthIncrease || 0;
    const maxHp = (s.maxHealth || 100) * (1 + (healthIncrease * 0.01));

    // Initialize battle pHp if it doesn't exist yet
    if (p.battle === undefined) p.battle = { pHp: maxHp };
    
    let currentHp = isNaN(p.battle.pHp) ? 0 : p.battle.pHp;
    const healAmount = 25; 
    
    p.battle.pHp = Math.min(currentHp + healAmount, maxHp);

    message.channel.send(`🔥 You drink from the Lava fountain and recover ${healAmount} HP. Now at ${Math.floor(p.battle.pHp)} HP.`);
    
    // Mark room as finished so they can move on
    p.dungeon.inRoom = false;
    p.dungeon.roomJustFinished = true;
    savePlayers();
}

if (message.content.startsWith('!escape')) {
    const p = players[message.author.id];
    
    // Check if they are in the Tavern Room
    if (p.dungeon?.inRoom && p.dungeon.roomType === 'Tavern') {
        // Calculate bonus for escaping early (maybe a flat percentage of their current dungeon earnings?)
        // For now, we just close the dungeon and grant them whatever they already earned
        
        p.dungeon.active = false;
        p.dungeon.inRoom = false;
        p.dungeon.roomType = null;
        p.ignis += 500;
    updateQuestProgress(userId, 'total_ignis_earned', 500, message.channel);
        return message.reply("🚪 **You escaped the dungeon safely!** Your progress has been saved and you've returned to the tavern. And earned bonus ignis!");
        
    } else {
        return message.reply("You can only escape if you are currently in a **Tavern Room**!");
    }
}

// --- Start the battle ---
if (message.content.startsWith('!qbattle') || message.content.startsWith('!quickbattle')) {
    const minion = minions[Math.floor(Math.random() * minions.length)];
    calculateStats(message.author.id); 
    const p = players[message.author.id];
    const s = p.stats;
    

    // Apply maxHealthIncrease (1 point = 1% increase)
    const bonusHpMult = 1 + (s.maxHealthIncrease * 0.01);
    const totalHp = Math.floor(s.maxHealth * bonusHpMult);

    p.battle = { 
        active: true,
        type: '!qbattle', 
        minion: minion, 
        mHp: minion.hp, 
        mArmor: minion.armor || 0,
        mMagicRes: minion.magicRes || 0,
        pHp: totalHp, 
        pArmor: s.armor || 0, 
        pMagicRes: s.magicRes || 0 
    };
    
    return message.reply(`⚔️ You encountered a **${minion.name}**! Type **!fight a** to attack.`);
}

if (message.content.startsWith('!fight ')) {
    const userId = message.author.id;
    const p = players[userId];
    
    // Safety check
    if (!p.battle || !p.battle.active) return message.reply("You aren't in a battle!");
    
    const args = message.content.split(' ');
    if (args.length < 2) return message.reply("Use `!fight attack` or `!fight run`!");
    
    const action = args[1].toLowerCase();
    const b = p.battle;
    const s = p.stats || {};
    let log = "";

    // 1. HANDLE ESCAPE (Speed Scaling)
    if (action === 'run' || action === 'r') {
        if (p.dungeon?.active) return message.reply("❌ **You cannot run from a dungeon!**");
        
        // Speed: 50% base + 1% per point
        const escapeChance = 0.5 + ((s.speed || 0) * 0.01);
        if (Math.random() < escapeChance) {
            b.active = false;
            savePlayers();
            return message.reply("💨 You used your speed to escape the encounter!");
        }
        log += "❌ Escape failed! ";
    } 

    // 2. HANDLE ATTACK (Crit, Lifesteal, & Boss Dialogue)
    else if (action === 'attack' || action === 'a') {
        const results = getCombatResults(p, b.minion, true);
        
        // --- CRIT FORMULA ---
        // Base 1.5x damage. Each point of critDamage adds 1% to the multiplier.
        const isCrit = Math.random() < ((s.critChance || 0) * 0.01);
        const critMult = 1.5 + ((s.critDamage || 0) * 0.01);
        const rawDmg = isCrit ? (results.damage * critMult) : results.damage;
        
     const targetDef = (b.minion.style === 'Magic') ? (b.minion.mMagicRes || 0) : (b.minion.mArmor || 0);
    const finalDmg = calculateDamage(rawDmg, targetDef);
        
        b.mHp = (b.mHp || 0) - finalDmg;
        log += `${isCrit ? "💥 **CRIT!** " : "⚔️ "}You hit **${b.minion.name}** for ${Math.floor(finalDmg)} dmg. `;
        
        // --- LIFESTEAL FORMULA (0.7% per point) ---
        if ((s.lifesteal || 0) > 0) {
            const healPercent = (s.lifesteal * 0.7) / 100;
            const healAmount = Math.floor(finalDmg * healPercent);
            const maxHp = (s.maxHealth || 100) * (1 + ((s.maxHealthIncrease || 0) * 0.01));
            
            b.pHp = Math.min((b.pHp || 100) + healAmount, maxHp);
            if (healAmount > 0) log += `(❤️ +${healAmount} HP) `;
        }

        // --- SECRET BOSS DIALOGUE ---
        if (b.minion.name === "Rebane - Collector's apprentice") {
            const hpPercent = (b.mHp / b.minion.hp) * 100;
            if (hpPercent <= 50 && !b.halfHpTriggered) {
                log += `\n🎭 **${b.minion.name}**: *"Human... You will never kill me-"*`;
                b.halfHpTriggered = true; 
            }
        }
    } else {
        return message.reply("Invalid action! Use `!fight attack` or `!fight run`.");
    }

    // 3. CHECK IF MINION DIED (Income Scaling)
    if (b.mHp <= 0) {
        b.active = false;
        const incomeBonus = 1 + ((s.income || 0) * 0.002); // Small increase per point
        const reward = Math.floor((b.minion.ignis || 100) * incomeBonus);
        p.ignis = (p.ignis || 0) + reward;

        // Special Boss Handling
        if (b.minion.name === "Rebane - Collector's apprentice") {
            updateAchievementProgress(userId, 'b6_completed', 1, message.channel);
            if (p.dungeon) p.dungeon.active = false;
            savePlayers();
            return message.reply(`🏆 You defeated the apprentice! He dissolves into ink. You gained ${reward} Ignis.`);
        }

        updateQuestProgress(userId, 'total_ignis_earned', reward, message.channel);
        savePlayers();
        if(p.battle.type === '!qbattle') updateQuestProgress(userId, 'quickbattle_wins', 1, message.channel);
        return message.reply(`🏆 You defeated the ${b.minion.name}! Gained ${reward} Ignis.`);
    }

    // 4. MINION TURN (Dodge, Damage Reduction, Thorns)
    const minionResults = getCombatResults(p, b.minion, false);
    
    // --- DODGE FORMULA (0.5% per point) ---
    const dodgeChance = (s.dodgeChance || 0) * 0.005;
    if (Math.random() < dodgeChance) {
        log += `\n✨ **DODGED!** The ${b.minion.name} missed completely!`;
    } else {
        const playerDef = (b.minion.style === 'Magic') ? (s.magicRes || 0) : (s.armor || 0);
    let baseDmgTaken = calculateDamage(minionResults.damage, playerDef);
            
        // --- DAMAGE REDUCTION & CRIT REDUCTION ---
        // Subtract 1 flat damage per point of damageReduction
        
        // Reduce enemy crit damage by 1% per point
        if (minionResults.isCrit) {
            const critReduc = Math.max(0, 1 - ((s.critDmgReduction || 0) * 0.01));
            dmgTaken *= critReduc;
        }

        b.pHp = (b.pHp || 100) - baseDmgTaken;
        log += `\n👹 The ${b.minion.name} hits you for ${Math.floor(baseDmgTaken)} dmg.`;

        // --- THORNS FORMULA (2 reflected per point) ---
        if ((s.thorns || 0) > 0) {
            const reflected = s.thorns * 2;
            b.mHp = (b.mHp || 0) - reflected;
            log += ` (🌵 Thorns: ${reflected} dmg reflected!)`;
        }
    }

    // 5. CHECK PLAYER DEATH
    if (b.pHp <= 0) {
        b.active = false;
        if (p.dungeon) p.dungeon.active = false;
        savePlayers();
        
        if (b.minion.name === "Rebane - Collector's apprentice") {
            return message.reply(`💀 **DEFEATED.** The Apprentice leans over you: *"Another soul for the collection."*`);
        }
        return message.reply(`💀 You were defeated by the ${b.minion.name}.`);
    }

    // 6. FINAL HP LOGGING
    log += `\n❤️ HP: ${Math.floor(b.pHp)} | Minion HP: ${Math.floor(Math.max(0, b.mHp))}`;
    savePlayers();
    return message.reply(log);
}

if (message.content.startsWith('!sell ')) {
    const args = message.content.substring(6).trim().split(/\s+/);
    const userId = message.author.id;
    const p = players[userId];
    if (!p) return message.reply("You haven't started playing!");

    let totalEarned = 0;
    let soldItems = [];
    let skippedItems = [];
    const itemsPerPage = 5; // Updated to match your inventory size

    const isSellable = (itemData) => {
        return itemData && typeof itemData.price === 'number' && itemData.rarity !== "Exclusive";
    };

    let indicesToSell = [];

    // 1. HANDLE "PAGE X"
    if (args[0].toLowerCase() === 'page') {
        const pageNum = parseInt(args[1]);
        if (isNaN(pageNum) || pageNum < 1) return message.reply("Please specify a valid page number (e.g., `!sell page 2`).");

        const startIndex = (pageNum - 1) * itemsPerPage;
        const endIndex = Math.min(startIndex + itemsPerPage, p.inventory.length);

        if (startIndex >= p.inventory.length) return message.reply("That page is empty!");

        for (let i = startIndex; i < endIndex; i++) {
            indicesToSell.push(i);
        }
    } 
    // 2. HANDLE "ALL"
    else if (args[0].toLowerCase() === 'all') {
        for (let i = 0; i < p.inventory.length; i++) {
            indicesToSell.push(i);
        }
    } 
    // 3. HANDLE SPECIFIC IDS
    else {
        indicesToSell = [...new Set(args.map(a => parseInt(a) - 1))]
            .filter(i => i >= 0 && i < p.inventory.length);
    }

    // Sort descending to prevent array index shifting
    indicesToSell.sort((a, b) => b - a);

    for (const index of indicesToSell) {
        const itemName = p.inventory[index];
        const itemData = items[itemName] || {};

        if (isSellable(itemData)) {
            totalEarned += Math.floor(itemData.price * 0.5);
            soldItems.push(itemName);
            p.inventory.splice(index, 1);
        } else if (itemData.rarity === "Exclusive") {
            skippedItems.push(itemName);
        }
    }

    if (soldItems.length === 0 && skippedItems.length === 0) {
        return message.reply("No valid items found to sell.");
    }

    p.ignis = (p.ignis || 0) + totalEarned;
    savePlayers();

    let response = `💰 Sold **${soldItems.length}** items for **${totalEarned} Ignis**!`;
    if (skippedItems.length > 0) {
        response += `\n⚠️ Skipped **${skippedItems.length}** Exclusive items.`;
    }
    
    message.reply(response);
}

if (message.content.startsWith('!equip ')) {
    const args = message.content.split(' ');
    const index = parseInt(args[1]) - 1;
    const p = players[userId];
    
    // 1. Get the item name from inventory
    const itemName = p.inventory[index];
    const items = require('./data/items.json');

    if (!itemName || !items[itemName]) return message.reply("Invalid item number!");
    
    // 2. Identify the slot
    const slotMap = { "Weapon": "weapon", "Helmet": "helmet", "Bodyarmor": "bodyarmor", "Leggings": "leggings", "Boots": "boots", "Ring": "ring" };
    const slot = slotMap[items[itemName].type];
    
    // 3. If something is already in that slot, put it BACK into inventory
    if (p.equippedSlots[slot]) {
        p.inventory.push(p.equippedSlots[slot]);
    }    
    // 4. Move the new item from inventory to the slot
    p.equippedSlots[slot] = itemName;
    
    // 5. REMOVE the item from the inventory (This is the missing step!)
    p.inventory.splice(index, 1);
    
    calculateFinalStats(userId);
    savePlayers();
  const questKeys = {
        'helmet': 'equip_helmet',
        'bodyarmor': 'equip_bodyarmor',
        'leggings': 'equip_leggings', // Note: Make sure this matches your JSON key!
        'boots': 'equip_boots',
        'ring': 'equip_ring',
        'weapon': 'equip_weapon'
    };

    if (questKeys[slot]) {
        updateQuestProgress(message.author.id, questKeys[slot], 1, message.channel);
    }
    
    message.reply(`Equipped **${itemName}**!`);

}
// Run this once to fix your data structure!


if (message.content.startsWith('!unequip ')) {
    let slot = message.content.replace('!unequip ', '').toLowerCase().trim();
    const p = players[message.author.id]; // Use message.author.id for consistency

    // 1. Define aliases to fix the typo
    const alias = {
        'leggins': 'leggings',
        'leg': 'leggings',
        'armor': 'bodyarmor', // Optional: adds convenience
        'weapon': 'weapon',
        'helmet': 'helmet',
        'bodyarmor': 'bodyarmor',
        'leggings': 'leggings',
        'boots': 'boots',
        'ring': 'ring'
    };

    // 2. Resolve the slot
    const slotToUnequip = alias[slot];
    if (!slotToUnequip) {
        return message.reply("Invalid slot! Choose from: weapon, helmet, bodyarmor, leggings, boots, ring.");
    }

    // 3. Check if there is something equipped
    // We check the resolved slot name. 
    const itemName = p.equippedSlots[slotToUnequip];
    
    if (!itemName) {
        return message.reply(`You don't have anything equipped in your ${slotToUnequip} slot!`);
    }

    // 4. Move the item back to inventory
    p.inventory.push(itemName);

    // 5. Clear the slot (set to null)
    p.equippedSlots[slotToUnequip] = null;

    // 6. Recalculate stats
    calculateFinalStats(message.author.id); 

    message.reply(`✅ Unequipped **${itemName}** from ${slotToUnequip}. It has been returned to your inventory.`);
    savePlayers();
}

if (message.content === '!gear') {
    const p = players[userId];
    let msg = "**--- 🛡️ Your Equipped Gear ---**\n";
    
    for (let slot in p.equippedSlots) {
        msg += `**${slot}:** ${p.equippedSlots[slot] || "Empty"}\n`;
    }
    
    message.channel.send(msg);
}

if (message.content.startsWith('!slots')) {
    const args = message.content.split(' ');
    const bet = parseInt(args[1]);

    if (isNaN(bet) || bet <= 0) {
      return message.reply("Usage: !slots <amount>");
    }

    if (players[userId].ignis < bet) {
      return message.reply("You don't have enough Ignis!");
    }

    // The symbols for your Phantom Tavern
    const symbols = ['🔥', '💀', '👻', '💎', '🕯️'];
    
    // Pick 3 random symbols
    const s1 = symbols[Math.floor(Math.random() * symbols.length)];
    const s2 = symbols[Math.floor(Math.random() * symbols.length)];
    const s3 = symbols[Math.floor(Math.random() * symbols.length)];

    const resultString = `[ ${s1} | ${s2} | ${s3} ]`;
    let messageResult = "";

    if (s1 === s2 && s2 === s3) {
      // JACKPOT (3 matching)
      const win = bet * 10;
      players[userId].ignis += (win - bet);
    updateAchievementProgress(userId, 'slots_jackpot_wins', 1, message.channel);
    updateQuestProgress(userId, 'total_ignis_earned', (win - bet), message.channel);
      messageResult = `🎊 **JACKPOT!** 🎊\n${resultString}\nAll three match! You won ${win} Ignis!`;
    } else if (s1 === s2 || s1 === s3 || s2 === s3) {
      // SMALL WIN (2 matching)
      const win = bet * 1.75;
      players[userId].ignis += (win - bet);

    updateQuestProgress(userId, 'total_ignis_earned', (win - bet), message.channel);
      messageResult = `✨ **MATCH!** ✨\n${resultString}\nA double! You won ${win} Ignis.`;
    } else {
      // LOSE
      players[userId].ignis -= bet;
      messageResult = `💀 **NO LUCK** 💀\n${resultString}\nBetter luck next time. You lost ${bet} Ignis.`;
    }

    savePlayers();
    message.reply(messageResult);
  }

  if (message.content.startsWith('!hl')) {
    const args = message.content.split(' ');
    const bet = parseInt(args[1]);

    if (isNaN(bet) || bet <= 0 || players[userId].ignis < bet) {
      return message.reply("Invalid bet or not enough Ignis!");
    }

    const card1 = Math.floor(Math.random() * 12) + 1;
    const card2 = Math.floor(Math.random() * 12) + 1;

    message.reply(`🃏 The first card is a **${card1}**. Is the next one **higher** or **lower**? (Type your answer)`);

    // This waits for the same user to reply within 15 seconds
    const filter = m => m.author.id === message.author.id && ['higher', 'lower'].includes(m.content.toLowerCase());
    
    message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
      .then(collected => {
        const guess = collected.first().content.toLowerCase();
        
        if (card1 === card2) {
          return message.reply(`The next card was also a **${card2}**! It's a draw, no Ignis lost.`);
        }

        const won = (guess === 'higher' && card2 > card1) || (guess === 'lower' && card2 < card1);

        if (won) {
          const profit = Math.floor(bet * 0.8); // 70% profit for the win
          players[userId].ignis += profit;

    updateQuestProgress(userId, 'total_ignis_earned', profit, message.channel);
          message.reply(`✅ The card was **${card2}**! You were right and earned ${profit} Ignis.`);
        } else {
          players[userId].ignis -= bet;
          message.reply(`❌ The card was **${card2}**... You guessed wrong and lost ${bet} Ignis.`);
        }
        savePlayers();
      })
      .catch(() => {
        message.reply("⌛ You took too long to decide! The dealer kept your Ignis.");
        players[userId].ignis -= bet;
        savePlayers();
      });
  }

  if (message.content.startsWith('!flip')) {
    const args = message.content.split(' ');
    const bet = parseInt(args[1]);
    const side = args[2]?.toLowerCase();

    if (isNaN(bet) || bet <= 0 || !['heads', 'tails'].includes(side)) {
      return message.reply("Usage: !flip <amount> <heads/tails>");
    }

    if (players[userId].ignis < bet) {
      return message.reply("You don't have enough Ignis!");
    }

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    
    if (side === result) {
      players[userId].ignis += bet;

    updateQuestProgress(userId, 'total_ignis_earned', bet, message.channel);
      message.reply(`🪙 It landed on **${result}**! You doubled your bet and won ${bet} Ignis!`);
    } else {
      players[userId].ignis -= bet;
      message.reply(`🪙 It landed on **${result}**. You lost ${bet} Ignis.`);
    }
    savePlayers();
  }

 if (message.content === '!shop') {
    const items = require('./data/items.json');
    const buyable = Object.keys(items).filter(name => items[name].canBuy === true);
    
    if (buyable.length === 0) return message.reply("The shop is currently empty.");

    let msg = "**--- 🛒 The Phantom Tavern Shop ---**\n\n";
    
    buyable.forEach((name, i) => {
        const item = items[name];
        
        // --- NEW LOGIC: Type and Style ---
        const itemType = item.type ? `[${item.type}] ` : "";
        const itemStyle = (item.type === "Weapon" && item.style) ? `(${item.style}) ` : "";
        
        // Format the stats object: ignore 0/null values for a cleaner look
        const statEntries = Object.entries(item.stats || {})
            .filter(([stat, val]) => val !== 0 && val !== undefined && val !== null)
            .map(([stat, val]) => stat.includes("Increase") ? `${stat}: ${val}%` : `${stat}: ${val}`)
            .join(', ');
        
        const statsDisplay = statEntries ? `| 🛡️ ${statEntries}` : "";
        
        msg += `**${i + 1}.** ${itemType}${itemStyle}${name} (${item.rarity})\n`;
        msg += `   └ 💰 ${item.price} Ignis ${statsDisplay}\n`;
    });
    
    msg += "\nType `!buy <number>` to purchase.";
    message.channel.send(msg);
}

if (message.content.startsWith('!buy ')) {
    const args = message.content.split(' ');
    const buyIndex = parseInt(args[1]) - 1;
    const items = require('./data/items.json');
    const p = players[userId];

    // Create an array of only the buyable items so the index matches the shop list
    const buyableItems = Object.keys(items).filter(name => items[name].canBuy === true);
    const itemName = buyableItems[buyIndex];

    // 1. Validate index
    if (!itemName) return message.reply("Invalid item number!");

    const item = items[itemName];

    // 2. Check money
    if (p.ignis < item.price) {
        return message.reply(`You need ${item.price} Ignis, but you only have ${p.ignis}.`);
    }

    // 3. Purchase
    p.ignis -= item.price;
    p.inventory.push(itemName);
    savePlayers();

    message.reply(`Successfully bought **${itemName}**!`);
    updateQuestProgress(message.author.id, 'shop_purchases', 1, message.channel);
}

  if (message.content === '!balance') {
    message.reply(`You have ${players[userId].ignis} Ignis units.`);
  }

  if (message.content === '!pot') {
    const p = players[message.author.id];
    
    // Safety check in case gachaPot is missing
    const pot = p.gachaPot || { "Almost Forged": 0, "Obsidian": 0 };
    
    let msg = `**--- 🏺 ${message.author.username}'s Pot ---**\n\n`;
    
    // Display each item in the pot
    for (const [item, count] of Object.entries(pot)) {
        msg += `**${item}**: ${count}\n`;
    }
    
    msg += "\n*Keep collecting!*";
    return message.channel.send(msg);
}

if (message.content === '!daily') {
    const userId = message.author.id;
    const p = players[userId]; // Access the player data directly
    const now = Date.now();
    const twentyHours = 20 * 60 * 60 * 1000;

    // Check if player has a claim record, if not, set to 0
    const lastUsed = p.lastDaily || 0;

    if (now - lastUsed < twentyHours) {
        const timeRemaining = twentyHours - (now - lastUsed);
        const hours = Math.floor(timeRemaining / (60 * 60 * 1000));
        const minutes = Math.floor((timeRemaining % (60 * 60 * 1000)) / (60 * 1000));
        return message.reply(`You already claimed your daily reward! Come back in ${hours}h ${minutes}m.`);
    }

    // Give the reward
    p.ignis = (p.ignis || 0) + 100;
    
    // Set the timestamp in the player object
    p.lastDaily = now; 
    
    savePlayers(); // This now saves the timestamp to the JSON file!
    
    message.reply('You received 100 units of Ignis! Come back in 20 hours.');
    updateQuestProgress(userId, 'daily_claims', 1, message.channel);
}

if (message.content.startsWith('!roulette')) {
    const args = message.content.split(' ');
    const bet = parseInt(args[1]);
    const choice = args[2]?.toLowerCase();

    if (!bet || !choice || (choice !== 'red' && choice !== 'black')) {
        return message.reply("Usage: !roulette <amount> <red/black>");
    }

    // Cooldown check (Ensure you have the 'cooldowns' Map defined earlier!)
    const userId = message.author.id;
    const now = Date.now();
    if (cooldowns.has(userId) && now < cooldowns.get(userId) + 1200) {
        return message.reply(`Slow down! You need to wait ${Math.round((cooldowns.get(userId) + 120000 - now) / 1000)} seconds.`);
    }

    if (players[userId].ignis < bet) {
        return message.reply("You don't have enough Ignis!");
    }

    const roll = Math.floor(Math.random() * 37); // 0 to 36
    const color = getColor(roll);
    
    // Check if the user's color choice matches the rolled color
    // We compare strings, so we capitalize the first letter of the choice
    const userChoiceCap = choice.charAt(0).toUpperCase() + choice.slice(1);

    if (roll === 0) {
        players[userId].ignis -= bet;
        message.reply(`The ball landed on 0 (Green). The House wins! You lost ${bet} Ignis. 💸`);
    } else if (color === userChoiceCap) {
        const multiplier = (choice === 'red') ? 2 : 3;
        const payout = bet * multiplier;
        players[userId].ignis += (payout - bet);

    updateQuestProgress(userId, 'total_ignis_earned', (payout - bet), message.channel);
        message.reply(`The ball landed on ${roll} (${color})! You won ${payout - bet} Ignis! 🎉`);
    } else {
        players[userId].ignis -= bet;
        message.reply(`The ball landed on ${roll} (${color}). You lost ${bet} Ignis. 💸`);
    }

    cooldowns.set(userId, now);
    savePlayers();

}


if (message.content === '!stats') {
    const p = players[userId];
    
    // 1. Force a recalculation of stats based on current equipment
    calculateStats(userId);
    
    const s = p.stats; 
    
    const statEmbed = `
**--- ${message.author.username}'s Profile ---**
❤️ HP: ${s.maxHealth} (+${s.maxHealthIncrease || 0}%) | ⚔️ DMG: ${s.dmg} | ⚡ Speed: ${s.speed}
🛡️ Armor: ${s.armor} | ✨ Magic Res: ${s.magicRes}
🩸 Lifesteal: ${s.lifesteal}% | 🍀 Luck: ${s.luck} | 🌵 Thorns: ${s.thorns || 0}
💰 Income: ${s.income}% | 🤸 Dodge: ${s.dodgeChance}%
🎯 Crit Chance: ${s.critChance}% | 💥 Crit Dmg: ${s.critDamage}% | 🛡️ Crit Red: ${s.critReduction || 0}%
💎 Ignis: ${p.ignis} \n
    Have Hammer: ${p.hammer}
    `;
    
    
    message.channel.send(statEmbed);
}

if (message.content.startsWith('!bar')) {
    const rianLines = [
        "The sharpest blade is useless if the hand that holds it trembles.",
        "A dungeon is just a cage until you find the key within yourself.",
        "Gold shines brightest in the pockets of those who didn't sell their soul for it.",
        "Victory is a fleeting mist; the scars you earn are the true map of your journey.",
        "Even the Great Kragnar was once a flickering candle in the dark.",
        "Don't fear the monsters in the deep; fear the silence when you stop fighting them.",
        "The tavern fire is warm, but it won't light the path to your destiny.",
        "Every wave you survive is a story written in blood and iron.",
        "A hero isn't the one who never falls, but the one who stands up with a heavier shield.",
        "Patience is the only potion that never runs dry.",
        "The weight of your armor is nothing compared to the weight of a guilty conscience.",
        "Rivers don't struggle against the rocks; they simply find a way around.",
        "Sometimes the greatest treasure is the lesson learned in a failed raid.",
        "A man who seeks only power will eventually find himself crushed by it.",
        "The stars don't care about your titles; they only care that you look up.",
        "Forgiveness is a magic stronger than any fire puppet's flame.",
        "The road to the fifth stage begins with a single, trembling step.",
        "Drink deep, traveler. Tomorrow the dungeon might not be so kind.",
        "Wisdom is knowing when to draw your sword—and when to keep it sheathed.",
        "In the end, we are all just characters in a story we didn't write."
    ];

    const randomLine = rianLines[Math.floor(Math.random() * rianLines.length)];
    updateAchievementProgress(message.author.id, 'b3_completed', 1, message.channel);
    
    return message.channel.send(`🍺 **The Bar**\n**Rian**: *"${randomLine}"*`);
}

const { EmbedBuilder } = require('discord.js');

if (message.content.startsWith('!quests')) {
    const userId = message.author.id;
    const p = players[userId];
    if (!p) return message.reply("You haven't started playing yet!");

    const args = message.content.split(' ');
    const pageArg = args[1];

    // 1. Pagination Setup
    const page = parseInt(pageArg) || 1;
    const itemsPerPage = 8; // Quests usually have longer descriptions, so 8 per page fits better
    const startIndex = (page - 1) * itemsPerPage;
    
    // questData comes from your require('./data/quests.json')
    const questsToShow = questData.slice(startIndex, startIndex + itemsPerPage);

    if (questsToShow.length === 0) return message.reply("That quest page is empty!");

    // 2. Build Embed
    const embed = new EmbedBuilder()
        .setTitle(`📜 Quest Log - Page ${page}`)
        .setDescription("Complete these tasks to earn extra Ignis and unique rewards!")
        .setColor(0x3498DB); // Blue color for Quests

    questsToShow.forEach(q => {
        // Checking player progress from players.json
        // Using the same structure as your achievements: p.quests.progress[key]
        const progress = (p.quests?.progress) ? (p.quests.progress[q.key] || 0) : 0;
        const isCompleted = (p.quests?.completed) ? p.quests.completed.includes(q.id) : false;
        
        const displayStatus = isCompleted 
            ? "✅ **Completed**" 
            : `⏳ **Progress:** ${progress} / ${q.target}`;
        
        const rewardText = q.itemReward ? q.itemReward : `${q.reward || 0} Ignis`;
        const displayIcon = isCompleted ? '🔹' : '🔸';

        embed.addFields({ 
            name: `${displayIcon} ${q.name}`, 
            value: `*${q.description}*\n${displayStatus} | **Reward:** ${rewardText}`, 
            inline: false 
        });
    });

    // 3. Footer for navigation
    const totalPages = Math.ceil(questData.length / itemsPerPage);
    embed.setFooter({ text: `Page ${page} of ${totalPages} | Type !quests <number> to switch pages` });

    message.reply({ embeds: [embed] });
}

if (message.content.startsWith('!achievements')) {
    const p = players[message.author.id];
    if (!p) return message.reply("You haven't started playing yet!");

    const args = message.content.split(' ');
    const pageArg = args[1];

    // 1. FILTER LOGIC:
    // If the user typed '?', show ONLY secrets.
    // If they typed a page number (or nothing), show ONLY non-secrets.
    const showSecretsOnly = (pageArg === '?');
    
    let list = showSecretsOnly 
        ? achievementData.filter(a => a.secret === true)
        : achievementData.filter(a => a.secret !== true); // <--- THIS EXCLUDES SECRETS

    // 2. Pagination
    const page = showSecretsOnly ? 1 : (parseInt(pageArg) || 1);
    const itemsPerPage = 10;
    const startIndex = (page - 1) * itemsPerPage;
    const achievementsToShow = list.slice(startIndex, startIndex + itemsPerPage);

    if (achievementsToShow.length === 0) return message.reply("That page is empty!");

    // 3. Build Embed
    const embed = new EmbedBuilder()
        .setTitle(showSecretsOnly ? "🕵️ Secret Achievements" : `🏆 Achievement Collection - Page ${page}`)
        .setColor(showSecretsOnly ? 0x2C3E50 : 0xF1C40F);

    achievementsToShow.forEach(ach => {
        const progress = (p.achievements?.progress) ? (p.achievements.progress[ach.key] || 0) : 0;
        const isCompleted = (p.achievements?.completed) ? p.achievements.completed.includes(ach.id) : false;
        
        // Even if an achievement is 'secret', once completed, we should show it!
        // So we allow it in the list if it's already completed by the player.
        const displayName = isCompleted ? ach.name : (ach.secret ? "???" : ach.name);
        const displayDesc = isCompleted ? ach.description : (ach.secret ? ` ${ach.description}*` : ach.description);
        const displayStatus = isCompleted ? "✅ Unlocked!" : (ach.secret ? "???" : `${progress} / ${ach.target}`);
        const displayIcon = isCompleted ? '✅' : (ach.secret ? '❓' : '🔒');
        
        const rewardText = ach.itemReward ? ach.itemReward : `${ach.reward || 0} Ignis`;

        embed.addFields({ 
            name: `${displayIcon} ${displayName}`, 
            value: `${displayDesc}\nStatus: **${displayStatus}** | Reward: **${rewardText}**`, 
            inline: false 
        });
    });

    message.reply({ embeds: [embed] });
}

if (message.content === '!rebuild') {
    const userId = message.author.id;
    const p = players[userId];
    if (!p) return;

    // 1. FIXED PATH: Checking p.dungeon.hammer instead of p.hammer
    // Also added p.dungeon check to prevent crashing if dungeon doesn't exist
    if (!p.hammer) {
        
        return message.reply("You didn't know how to help. You said sorry to the creature.. (Unlock Hammer to use this command).");
    }

    // 2. Check if the event is active
    if (p.ruinsEvent !== 'grave_rebuild') {
         p.ruinsEvent = null;
        return message.reply("There is nothing here that needs rebuilding right now.");

    }

    // 3. Reset the event flag
    p.ruinsEvent = null;
    
    // 4. Progress and Rewards
    updateAchievementProgress(userId, 'b1_completed', 1, message.channel);
    let bonus = 250;
    p.ignis = (p.ignis || 0) + bonus;
    savePlayers();

    // 5. FIXED QUOTES: Changed " " to ` ` so ${bonus} works
    return message.reply(`🪦 You spend the afternoon carefully restoring the ancient grave. The Masked Creature bows deeply before vanishing. You feel a sense of profound peace. The creature didn't have much, but it awarded you with **${bonus} Ignis**!`);
}

if (message.content.startsWith('!forge')) {
    const args = message.content.split(' ');
    const userId = message.author.id;
    const p = players[userId];
    
    // 1. Hammer Check
    if (!p.hammer) {
        return message.reply("🔨 You need the **Hammer** to forge! (Complete Stage 5 to unlock it).");
    }

    // --- SPECIAL FORGE (BA004 Logic) ---
    if (args.length === 3) {
        const slot1 = parseInt(args[1]) - 1; // Convert to 0-based index
        const slot2 = parseInt(args[2]) - 1;

        if (isNaN(slot1) || isNaN(slot2) || !p.inventory[slot1] || !p.inventory[slot2] || slot1 === slot2) {
            return message.reply("❌ Invalid slots! Use: `!forge [slot1] [slot2]` (e.g., `!forge 1 2`)");
        }

        const item1 = p.inventory[slot1];
        const item2 = p.inventory[slot2];
        const required = ["Sword of black stone", "Sword of white stone"];

        // Check if both items are present (ignores order)
        if (required.includes(item1) && required.includes(item2)) {
            
            // Remove the items (highest index first to avoid shifting issues)
            const indicesToRemove = [slot1, slot2].sort((a, b) => b - a);
            p.inventory.splice(indicesToRemove[0], 1);
            p.inventory.splice(indicesToRemove[1], 1);

            message.channel.send("🌑⚪ **The stones begin to glow...**");
            // Change this line in the !forge command:
updateAchievementProgress(userId, 'b4_completed', 1, message.channel);
            savePlayers();
            return; 
        } else {
            return message.reply("❌ Those items cannot be forged together!");
        }
    }

    // --- STANDARD FORGE (Income Logic) ---
    const now = Date.now();
    const oneHour = 1 * 60 * 60 * 1000;
    const lastUsed = p.lastForge || 0;

    if (now - lastUsed < oneHour) {
        const timeRemaining = oneHour - (now - lastUsed);
        const minutes = Math.ceil(timeRemaining / (60 * 1000));
        return message.reply(`⏳ Your forge is cooling down! Come back in ${minutes} minutes.`);
    }

    const profit = Math.floor(Math.random() * (1100 - 250 + 1)) + 250;
    p.ignis = (p.ignis || 0) + profit;
    p.lastForge = now;
    
    savePlayers();
    message.reply(`🔥 You forged a masterpiece and sold it for **${profit} Ignis**!`);
}

if (message.content === '!ruins') {
    const userId = message.author.id;
    const p = players[userId];
    const now = Date.now();
    const cooldown = 2 * 60 * 60 * 1000; // 2 Hours

    // 1. Cooldown Check
    const lastRuins = p.lastRuins || 0;
    if (now - lastRuins < cooldown) {
        const remaining = cooldown - (now - lastRuins);
        const mins = Math.ceil(remaining / (60 * 1000));
        return message.reply(`🏚️ The ruins are too quiet right now. Come back in **${mins} minutes**.`);
    }

    const roll = Math.random(); // Generates 0.0 to 1.0
    p.lastRuins = now;

    // 2. Event Probabilities
    if (roll < 0.2) { 
    // --- SHADOWY FIGURE ENCOUNTER ---
    p.ruinsEvent = 'shadow_figure'; 
    savePlayers();
    
    // We send this message to notify them of the choice
    return message.reply("🌑 **A chill runs down your spine.**\nYou spot a **Shadowy Figure** moving through the mist. It looks back, waiting to see if you are brave enough to follow... \nType **!follow** to pursue or **!ignore it**.");
}   
 else if (Math.random() < 0.3) {
            const bonus = 1000;
             p.ignis = (p.ignis || 0) + bonus;
            p.ruinsEvent = 'grave_rebuild'; // Set the flag for !rebuild
            savePlayers();
            return message.reply(`⚒️ **REBUILD!** You fixed a merchant stall for **${bonus} Ignis**.\n\n🎭 Suddenly, a **Masked Creature** emerges from the shadows. It begs for your help rebuilding the grave of a loved one. \nType **!rebuild** to help them (this will not cost Ignis).`);
        }

    else if (roll < 0.4) {
        // --- 18% UNCOMMON: Rebuild Event ---
        const bonus = 1000;

        p.ignis = (p.ignis || 0) + bonus;
        savePlayers();
        return message.reply(`⚒️ **REBUILD!** You found a collapsed merchant stall and spent hours fixing the frame. The locals rewarded your hard work with **${bonus} Ignis**!`);
    } 
    else if (roll < 0.60) {
        // --- 40% COMMON: Finding Items to Sell ---
        const profit = Math.floor(Math.random() * (1000 - 300 + 1)) + 300;
        p.ignis = (p.ignis || 0) + profit;
        savePlayers();
        return message.reply(`🏺 You scavenged some ancient pottery and rusted gears. You sold them at the camp for **${profit} Ignis**.`);
    } 
    else {
        // --- 40% FAIL: Find Nothing ---
        savePlayers();
        return message.reply("💨 You searched the ruins for hours, but found nothing but dust and echoes.");
    }
}




if (message.content === '!follow') {
    const userId = message.author.id;
    const p = players[userId];

    // --- STAGE 1: Following from the Ruins to the Dungeon Entrance ---
    if (p.ruinsEvent === 'shadow_figure') {
        p.ruinsEvent = 'shadow_dungeon_entrance'; 
        savePlayers();
        return message.reply("👣 You follow the figure through a narrow, dark path. The air grows cold as you reach a hidden, crumbling dungeon entrance. The figure slips inside and waits for you at the threshold... \nDo you **!follow** him inside, or **!ignore** the danger?");
    }

    // --- STAGE 2: Entering for the Secret Boss Fight ---
    if (p.ruinsEvent === 'shadow_dungeon_entrance') {
        p.ruinsEvent = null; 

        // UPDATED: Now spawns the Collector's Apprentice
        const enemy = boss['collectors_apprentice']; 
        
        if (!enemy) {
            console.log("[ERROR] collectors_apprentice not found in boss object!");
            return message.reply("The figure vanished into a glitch in the abyss... (Boss data missing)");
        }

        // Initialize the dungeon state
        // We preserve the 'hammer' status so they don't lose it if they already have it

        p.dungeon = {
            active: true,
            type: '!ruins_secret',
            stage: 'secret',
            currentWave: 1,
            totalWaves: 1,
            difficulty: 'nightmare',
        };

        // Prepare the battle object
        const s = p.stats || { maxHealth: 100, maxHealthIncrease: 0 };
        const maxHp = (s.maxHealth || 100) * (1 + ((s.maxHealthIncrease || 0) * 0.01));
        
        p.battle = { 
            active: true, 
            minion: enemy, 
            mHp: enemy.hp, 
            pHp: maxHp,
            pArmor: s.armor || 0, 
            pMagicRes: s.magicRes || 0 
        };

        savePlayers();
        return message.channel.send(`🌑 **THE SHADOW REVEALS ITSELF.**\n**${enemy.name}**: *" ${enemy.dialogue} "*\n\n⚔️ **A Nightmare Battle Begins!** Use **!nextwave**!`);
    }

    return message.reply("There is nothing here to follow.");
}
if (message.content === '!ignore') {
    const p = players[message.author.id];
    if (p.ruinsEvent === 'shadow_figure' || p.ruinsEvent === 'shadow_dungeon_entrance') {
        p.ruinsEvent = null;
        savePlayers();
        return message.reply("⚠️ You decide the risk isn't worth it and retreat to the safety of the camp. The shadows dissipate.");
    } {
        return message.reply("You.. ignored nothing? Nice job...");
    }
}
    

if (message.content.startsWith('!gacha')) {
    const args = message.content.split(' ').slice(1);
    const userId = message.author.id;
    const cost = 500;

    if (!players[userId]) players[userId] = { ignis: 0, inventory: [], gachaPot: { "Almost Forged": 0, "Obsidian": 0 } };
    const p = players[userId];
    if (!p.gachaPot) p.gachaPot = { "Almost Forged": 0, "Obsidian": 0 };

    const bannerMap = { '1': 'Almost Forged', '2': 'Obsidian' };
    const selectedBanner = bannerMap[args[0]];

    if (args.length === 2 && args[1] === 'info') {
        if (!selectedBanner) return message.reply("Invalid banner!");
        const legendaries = Object.keys(items).filter(n => items[n].rarity === 'Legendary' && items[n].banner === selectedBanner);
        return message.channel.send(`**📜 ${selectedBanner} Saga Info**\nRates: Secret 0.5%, Legendary 0.5%, Epic 9%, Rare 30%, Common 60%\nFeatured Legendary: ${legendaries.join(', ') || "None"}\n`);
    }

    if (args.length === 0) {
        return message.channel.send("**🎲 Gacha Banners - each pull costs 500 Ignis**\n1. **Almost Forged Saga**\n2. **Obsidian Saga**\nType `!gacha <banner> <amount>` to pull!");
    }

    if (!selectedBanner) return message.reply("Invalid banner!");
    const pullAmount = parseInt(args[1]) || 1;
    const totalCost = cost * pullAmount;

    if (p.ignis < totalCost) return message.reply(`Not enough Ignis!`);

    let results = [];
    let legendariesWonCount = 0; // TRACKER FOR ACHIEVEMENT BA007

    for (let i = 0; i < pullAmount; i++) {
        let rolledRarity = null;
        let isExclusive = false;

        if (p.gachaPot[selectedBanner] >= 60) rolledRarity = "Legendary";
        else {
            const rand = Math.random();
            if (pullAmount === 10 && i === 9 && !rolledRarity) rolledRarity = "Epic";
            else if (rand > 0.995) isExclusive = true;
            else if (rand > 0.99) rolledRarity = "Legendary";
            else if (rand > 0.90) rolledRarity = "Epic";
            else if (rand > 0.60) rolledRarity = "Rare";
            else rolledRarity = "Common";
        }

        // --- Achievement Logic ---
        if (rolledRarity === "Legendary") {
            legendariesWonCount++; // Increment the session counter
        }

        let pool, wonItem;
        if (isExclusive) {
            pool = Object.keys(items).filter(n => items[n].rarity === "Exclusive" && items[n].banner === selectedBanner);
        } else if (rolledRarity === "Legendary") {
            pool = Object.keys(items).filter(n => items[n].rarity === "Legendary" && items[n].banner === selectedBanner);
            p.gachaPot[selectedBanner] = 0;
        } else {
            pool = Object.keys(items).filter(n => items[n].rarity === rolledRarity);
            p.gachaPot[selectedBanner] += 1;
        }

        wonItem = pool[Math.floor(Math.random() * pool.length)];
        p.inventory.push(wonItem);

        const rarityLabel = isExclusive ? "Exclusive" : rolledRarity;
        let colorCode = "34"; 
        if (rarityLabel === "Legendary") colorCode = "1;33";
        else if (rarityLabel === "Epic") colorCode = "35";
        else if (rarityLabel === "Rare") colorCode = "33";
        else if (rarityLabel === "Exclusive") colorCode = "1;31";

        results.push(`\u001b[0;${colorCode}m${rarityLabel}: ${wonItem}\u001b[0m`);
    }

    p.ignis -= totalCost;

    // --- UPDATE BA007 PROGRESS ---
    if (legendariesWonCount > 0) {
        updateAchievementProgress(userId, 'b7_completed', legendariesWonCount, message.channel);
    }

    savePlayers();

    const response = pullAmount === 1 
        ? `🎲 You spent 💰 ${cost}.\n\`\`\`ansi\n${results[0]}\n\`\`\`\n*Pot: ${p.gachaPot[selectedBanner]}/60*`
        : `🎲 **${pullAmount}-Pull Results:**\n\`\`\`ansi\n${results.join('\n')}\n\`\`\`\n*Total Spent: 💰 ${totalCost} | Current Pot: ${p.gachaPot[selectedBanner]}/60*`;
    
    updateQuestProgress(userId, 'gacha_opened', pullAmount, message.channel);
    updateAchievementProgress(userId, 'gacha_opened', pullAmount, message.channel);
    
    return message.channel.send(response);
}

if (message.content === '!helper') {
    const helpPart1 = `
**──────── 💠 PHANTOM TAVERN GUIDE 💠 ────────**

**⚔️ COMBAT & DUNGEONS**
• \`!dungeon <easy/medium/hard>\` - Enter a random dungeon.
• \`!stages\` - Enter progressive stages (Unlocks Stage 1-5).
• \`!quickbattle\` - Quick single combat.
• \`!nextwave\` - Progress to the next enemy or claim rewards.
• \`!fight attack\` (or \`!fight a\`) - Attack your current target.
• \`!fight run\` (or \`!fight r\`) - Attempt to flee.

**🗺️ EXPLORATION & EVENTS**
• \`!daily\` - Get daily ignis.
• \`!ruins\` - Search the ruins (1-hour cooldown).
• \`!follow\` / \`!ignore\` - Make choices in ruins.
• \`!drink\` / \`!escape\` / \`!tip <amount>\` / \`!openchest\` - Use inside Dungeon Rooms.
• \`!rebuild\` - Use in ruins for bonus ignis.
• \`!forge\` - Craft items to sell to peasants.
• \`!bar\` - Get a deep quote from Rian the bartender, Thanks Rian.

**🎲 GACHA & ECONOMY**
• \`!gacha\` - View banners and pity count.
• \`!gacha <1/2> <amount>\` - Pull from Saga 1 or 2 (500 Ignis).
• \`!gacha <1/2> info\` - View rates and featured items.
• \`!pot\` - See your guaranteed legendary progress (Pity at 60).
• \`!shop\` - Browse items in shop.
• \`!buy <number>\` - Buys item from shop.
• \`!balance\` - Check your current Ignis.
    `;

    const helpPart2 = `
**📜 CHARACTER & PROGRESS**
• \`!stats\` - View your combat attributes.
• \`!inventory\` - Browse your collected items.
• \`!page <number>\` - View different pages of your inventory.
• \`!sell <number>\` - Sell an item (or use \`!sell all\`).
• \`!equip <number>\` - Equip gear by its inventory number.
• \`!gear\` - See currently equipped gear.
• \`!unequip <item name>\` - Unequips specific items.
• \`!quests\` - View active quests and progress.
• \`!achievements\` - Check milestone progress and secret kills.
• \`!leaderboard\` - See top 10 players.

**🎮 MINI-GAMES**
• \`!roulette <amount> <red/black>\` - Gamble on colors.
• \`!hl <amount>\` - Play Higher or Lower.
• \`!flip <amount> <heads/tails>\` - Coinflip gamble.
• \`!slots <amount>\` - Try your luck at the slots.

    `;

    // Send Part 1, then Part 2
    message.channel.send(helpPart1).then(() => {
        message.channel.send(helpPart2);
    });
    return;
}

// ... all your other code ...
savePlayers();
});

// This closes the client.on('messageCreate', ...) block

client.login('MTQ4MDkxMDU0MDQwNTYwODQ5MA.GAmAJD.ghHnapJVZ-oPOajfaIX-QC148sQOlAeIdXVziw');

